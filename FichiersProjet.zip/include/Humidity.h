#include "Sensor.h"


class Humidity : public Sensor
{
    public:
        Humidity();
        virtual ~Humidity();

    protected:

    private:
};
