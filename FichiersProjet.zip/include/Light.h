#include "Sensor.h"


class Light : public Sensor
{
    public:
        Light();
        virtual ~Light();

    protected:

    private:
};
