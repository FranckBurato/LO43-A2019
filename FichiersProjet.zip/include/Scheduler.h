#include "Sensor.h"
#include "Temperature.h"
#include "Humidity.h"
#include "Sound.h"
#include "Light.h"


class Scheduler
{
    public:
        Scheduler();
        Scheduler(Temperature, Humidity, Sound, Light, Server);
        virtual ~Scheduler();
        Scheduler(const Scheduler& other);

        Temperature getTemp();
        void setTemp(Temperature);

        Humidity getHum();
        void setHum(Humidity);

        Sound getSound();
        void setSound(Sound);

        Light getLight();
        void setLight(Light);

        Server getServer();
        void setServer(Server);

        void displayValues();
		void start();

    protected:

    private:
        Temperature temperature;
        Humidity humidity;
        Sound sound;
        Light light;
        Server server;

};