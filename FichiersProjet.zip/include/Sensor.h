#ifndef DEF_SENSOR
#define DEF_SENSOR

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Server.h"

class Sensor
{
    public:
        Sensor();
        Sensor(int);
        virtual ~Sensor();
        Sensor(const Sensor& other);

        int sendData(Server s);
        int aleaGenVal();
		void setValue(int);
		int getValue();

    protected:

    private:
        int valSense;
};

#endif