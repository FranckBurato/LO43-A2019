#ifndef DEF_SERVER
#define DEF_SERVER

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string>

using namespace std;


class Server
{
    public:
        Server();
        Server(int, bool, bool);
        virtual ~Server();
        Server(const Server& other);
        Server& operator=(const Server& s);
		void operator>>(string);
		friend void operator>>(int, string);

		void setNbrSensor(int);
		int getNbrSensor();

		void dataRcv(int, int);
		void consoleWrite(string);
		void fileWrite(string, int);

    protected:

    private:
        int nbrOfSensors;
        bool consolActivation;
        bool logActivation;
};

#endif