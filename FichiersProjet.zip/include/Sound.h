#include "Sensor.h"


class Sound : public Sensor
{
    public:
        Sound();
        virtual ~Sound();

    protected:

    private:
};
