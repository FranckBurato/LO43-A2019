#include "Sensor.h"


class Temperature : public Sensor
{
    public:
        Temperature();
        virtual ~Temperature();

    protected:

    private:
};
