#include "../include/Humidity.h"

Humidity::Humidity()
{
    //ctor
}

Humidity::~Humidity()
{
    //dtor
}

