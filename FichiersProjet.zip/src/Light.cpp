#include "../include/Light.h"
#include <time.h>

Light::Light()
{
    //ctor
}

Light::~Light()
{
    //dtor
}
