#include "../include/Scheduler.h"

int main()
{
	srand(time(NULL));
	Scheduler* s = new Scheduler();
	s->displayValues();
	s->start();

	system("PAUSE");
	return 0;
}