#include "../include/Scheduler.h"

Scheduler::Scheduler()
{
    temperature.setValue(temperature.aleaGenVal());
	humidity.setValue(humidity.aleaGenVal());
	sound.setValue(sound.aleaGenVal());
	light.setValue(light.aleaGenVal());
	server.setNbrSensor(4);
}

Scheduler::Scheduler(Temperature t, Humidity h, Sound s, Light l, Server se)
{
    temperature = t;
    humidity = h;
    sound = s;
    light = l;
    server = se;
}

Scheduler::~Scheduler()
{
    //dtor
}

Scheduler::Scheduler(const Scheduler& other)
{
    //copy ctor
}

Temperature Scheduler::getTemp()
{
    return temperature;
}

void Scheduler::setTemp(Temperature t)
{
    temperature = t;
}

Humidity Scheduler::getHum()
{
    return humidity;
}

void Scheduler::setHum(Humidity h)
{
    humidity = h;
}

Sound Scheduler::getSound()
{
    return sound;
}

void Scheduler::setSound(Sound s)
{
    sound = s;
}

Light Scheduler::getLight()
{
    return light;
}

void Scheduler::setLight(Light l)
{
    light = l;
}

Server Scheduler::getServer()
{
    return server;
}

void Scheduler::setServer(Server se)
{
    server = se;
}

void Scheduler::displayValues()
{
	cout << "===============================================" << endl
		<< "Les valeurs actuelles des capteurs sont : " << endl
		<< "Temperature : " << temperature.getValue() << endl
		<< "Son : " << sound.getValue() << endl
		<< "Humidite : " << humidity.getValue() << endl
		<< "Lumiere : " << light.getValue() << endl << endl
		<< "===============================================" << endl;
}

void Scheduler::start()
{
	int timer = 0;
	while (true){
		timer += 1;
		if(timer%1000000) {
			server.dataRcv(temperature.sendData(server), 1);
		}
	}
}
