#include "../include/Sensor.h"

Sensor::Sensor()
{
    valSense = -1;
}

Sensor::Sensor(int v)
{
    valSense = v;
}

Sensor::~Sensor()
{
    //dtor
}

Sensor::Sensor(const Sensor& other)
{
    valSense = other.valSense;
}

int Sensor::sendData(Server s)
{
	return valSense;
}

int Sensor::aleaGenVal()
{
    srand(time(NULL));
    int v = rand()%100;
    return v;
}

void Sensor::setValue(int v)
{
	valSense = v;
}

int Sensor::getValue()
{
	return valSense;
}
