#include "../include/Server.h"
#include <fstream>

using namespace std;

Server::Server()
{
    nbrOfSensors = 0;
    consolActivation = 0;
    logActivation = 0;
}

Server::Server(int n, bool c, bool l)
{
    nbrOfSensors = n;
    consolActivation = c;
    logActivation = l;
}

Server::~Server()
{
    //dtor
}

Server::Server(const Server& other)
{
    nbrOfSensors = other.nbrOfSensors;
    consolActivation = other.consolActivation;
    logActivation = other.logActivation;
}

Server& Server::operator=(const Server &other)
{
    nbrOfSensors = other.nbrOfSensors;
    consolActivation = other.consolActivation;
    logActivation = other.logActivation;
    return *this;
}

void Server::operator>>(string data)
{
	consoleWrite(data);
    return;
}

/*void operator>>(int nFile, string data)
{
	fileWrite(data, nFile);
	return;
}*/

void Server::setNbrSensor(int n)
{
	nbrOfSensors = n;
}

int Server::getNbrSensor()
{
	return nbrOfSensors;
}

void Server::dataRcv(int data, int typeOfSensor) //typeOfSensor : 1=temperature / 2=humidity / 3=sound / 4=light
{
	consoleWrite(to_string(data));
	fileWrite(to_string(data),typeOfSensor);
}

void Server::consoleWrite(string data)
{
	cout << "Les données sont : " << data << endl;
}

void Server::fileWrite(string data, int nFile)
{
    string file = "C:\\Users\\User\\Desktop\\UTBM\\Semestre 1\\LO43\\data";
    string file2 = { file + to_string(nFile)};
    string a = ".txt";
    string file3 = { file2 + a };
	ofstream flux(file3);

	if(flux){
		flux << data << " " << endl;
	}
	else{
		cout << "ERREUR: Impossible d'ouvrir le fichier." << endl;
	}
}
