#include "../include/Sound.h"

Sound::Sound()
{
    //ctor
}

Sound::~Sound()
{
    //dtor
}
