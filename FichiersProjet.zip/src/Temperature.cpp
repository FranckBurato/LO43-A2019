#include "../include/Temperature.h"

Temperature::Temperature()
{
    //ctor
}

Temperature::~Temperature()
{
    //dtor
}
