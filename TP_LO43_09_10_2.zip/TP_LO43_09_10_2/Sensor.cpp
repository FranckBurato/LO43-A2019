#include <iostream>
#include "Server.h"
#include "Sensor.h"

using namespace std;

Sensor::Sensor() : valSense(0)
{}

Sensor::~Sensor()
{}

Temperature::Temperature() : Sensor()
{}

Temperature::~Temperature()
{}

Humidity::Humidity() : Sensor()
{}

Humidity::~Humidity()
{}

Light::Light() : Sensor()
{}

Light::~Light()
{}

Sound::Sound() : Sensor()
{}

Sound::~Sound()
{}
