#ifndef SENSOR_H_INCLUDED
#define SENSOR_H_INCLUDED
#include "Sensor.h"

template <class T>
class Sensor
{
protected:
    T valSense;

public:
    Sensor();
    Sensor(T value) : valSense(value)
    {}
    ~Sensor();
};


//classes filles

class Temperature : private Sensor
{
public:
    Temperature();
    ~Temperature();
};

class Humidity : private Sensor
{
public:
    Humidity();
    ~Humidity();
};

class Light : private Sensor
{
public:
    Light();
    ~Light();
};

class Sound : private Sensor
{
public:
    Sound();
    ~Sound();
};

#endif // SENSOR_H_INCLUDED
