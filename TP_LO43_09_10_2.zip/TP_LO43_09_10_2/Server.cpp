#include <iostream>
#include "Server.h"

using namespace std;

Server::Server():nbrOfSensors(0), consoleActivation(true), logActivation(false)
{}

Server::Server(Server &server_p)
{
    nbrOfSensors=server_p.nbrOfSensors;
    consoleActivation=server_p.consoleActivation;
    logActivation=server_p.logActivation;
}

Server::Server(int nbrOfSensors, bool consoleActivation, bool logActivation) : nbrOfSensors(nbrOfSensors), consoleActivation(consoleActivation), logActivation(logActivation)
{}

Server::~Server()
{}

Server& Server::operator=(Server &server_p)
{
    nbrOfSensors=server_p.nbrOfSensors;
    consoleActivation=server_p.consoleActivation;
    logActivation=server_p.logActivation;
    return *this;
}

ostream& Server::operator<<(int dataSens)
{
    cout << dataSens;
}

ostream &operator<<(string dataSens, int dataType)
{
    //En fonction de dataType, on écrira la dataSens dans le log 1,2... (=temp, humi ...)
}
