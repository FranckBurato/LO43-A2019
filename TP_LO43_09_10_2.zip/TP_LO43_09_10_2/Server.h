#ifndef SERVER_H_INCLUDED
#define SERVER_H_INCLUDED

class Server
{
    //attribut
private:
    int nbrOfSensors;
    bool consoleActivation;
    bool logActivation;

    //methode
public:
    Server();
    Server(Server &server_p);
    Server(int nbrOfSensors, bool consoleActivation, bool logActivation);
    ~Server();

    Server &operator=(Server &server_p);
    std::ostream &operator<<(int dataSens);
    friend std::ostream &operator<<(std::string dataSens, int dataType);
    /*void consoleWrite(std::ostream& flux);
	void fileWrite(std::ostream& flux)*/
};

#endif // SERVER_H_INCLUDED
