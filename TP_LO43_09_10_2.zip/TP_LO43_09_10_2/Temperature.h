#ifndef TEMPERATURE_H_INCLUDED
#define TEMPERATURE_H_INCLUDED
#include "Sensor.h"

class Temperature : private Sensor
{
public:
    Temperature();
    ~Temperature();
};

#endif // TEMPERATURE_H_INCLUDED
